<?php
// ============================================================
// index.php
// Homepage - Displays all products in a grid layout
// ============================================================

session_start();                        // Start session for cart & login
require_once 'config/db.php';           // Include database connection

// Count items currently in cart (for nav badge)
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;

// Fetch all products from the database
$result = mysqli_query($conn, "SELECT * FROM products ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ShopZone - Online Store</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- ========== NAVBAR ========== -->
<nav class="navbar">
    <div class="container">
        <a href="index.php" class="navbar-brand">Shop<span>Zone</span></a>
        <ul class="navbar-nav">
            <li><a href="index.php" class="active">🏠 Home</a></li>
            <li>
                <a href="user/cart.php">
                    🛒 Cart
                    <?php if ($cart_count > 0): ?>
                        <span class="cart-badge"><?= $cart_count ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <?php if (isset($_SESSION['admin_logged_in'])): ?>
                <li><a href="admin/dashboard.php">⚙️ Admin</a></li>
                <li><a href="admin/logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="admin/login.php">Admin Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<!-- ========== HERO SECTION ========== -->
<section class="hero">
    <div class="container">
        <h1>Find Your <em>Perfect</em><br>Product Today</h1>
        <p>Discover our handpicked collection of premium products at unbeatable prices.</p>
        <a href="#products" class="btn btn-primary">Browse Products ↓</a>
    </div>
</section>

<!-- ========== PRODUCTS SECTION ========== -->
<div class="container wrapper" id="products">
    <div class="page-header">
        <h2>All Products</h2>
        <span style="color:var(--text-muted); font-size:.9rem;">
            <?= mysqli_num_rows($result) ?> items available
        </span>
    </div>

    <?php if (isset($_SESSION['msg'])): ?>
        <div class="alert alert-success">✅ <?= htmlspecialchars($_SESSION['msg']) ?></div>
        <?php unset($_SESSION['msg']); ?>
    <?php endif; ?>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <div class="products-grid">
            <?php while ($product = mysqli_fetch_assoc($result)): ?>
                <div class="card product-card">
                    <!-- Product Image -->
                    <div class="product-image">
                        <?php
                        $img_path = 'assets/images/' . $product['image'];
                        if (file_exists($img_path) && $product['image'] !== 'default.jpg'):
                        ?>
                            <img src="<?= $img_path ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                        <?php else: ?>
                            <div class="img-placeholder">🖼️</div>
                        <?php endif; ?>
                    </div>

                    <!-- Product Details -->
                    <div class="product-body">
                        <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                        <div class="product-desc"><?= htmlspecialchars($product['description']) ?></div>
                        <div class="product-price">₹<?= number_format($product['price'], 2) ?></div>

                        <!-- Add to Cart Form -->
                        <form action="user/add_to_cart.php" method="POST">
                            <input type="hidden" name="product_id"   value="<?= $product['id'] ?>">
                            <input type="hidden" name="product_name"  value="<?= htmlspecialchars($product['name']) ?>">
                            <input type="hidden" name="product_price" value="<?= $product['price'] ?>">
                            <input type="hidden" name="product_image" value="<?= $product['image'] ?>">
                            <button type="submit" class="btn btn-primary btn-sm btn-block">
                                🛒 Add to Cart
                            </button>
                        </form>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

    <?php else: ?>
        <!-- Empty state when no products exist -->
        <div class="empty-state">
            <span class="empty-icon">📦</span>
            <h3>No Products Yet</h3>
            <p>Check back later or visit the admin panel to add products.</p>
        </div>
    <?php endif; ?>
</div>

<!-- ========== FOOTER ========== -->
<footer class="footer">
    <p>© 2024 ShopZone &mdash; mitsinh Gohil</p>
</footer>

</body>
</html>
<?php mysqli_close($conn); ?>
