-- ============================================================
-- E-Commerce Mini Website Database Schema
-- Project by: Aaditya Sevani, Rudra Sedani, Maandeepsinh Gohil
-- ============================================================

-- Create and select database
CREATE DATABASE IF NOT EXISTS ecommerce_db;
USE ecommerce_db;

-- ------------------------------------------------------------
-- Table: users
-- Stores admin and regular user accounts
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,       -- Stored as MD5 hash
    role ENUM('admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- Table: products
-- Stores all product information
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    description TEXT,
    image VARCHAR(255) DEFAULT 'default.jpg',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- Table: orders (for checkout simulation)
-- Stores placed orders
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_address TEXT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- Table: order_items
-- Stores individual items in each order
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- Default Admin User
-- Username: admin | Password: admin123
-- ------------------------------------------------------------
INSERT INTO users (username, password, role) VALUES
('admin', MD5('admin123'), 'admin');

-- ------------------------------------------------------------
-- Sample Products Data
-- ------------------------------------------------------------
INSERT INTO products (name, price, description, image) VALUES
('Wireless Headphones', 1299.99, 'Premium quality wireless headphones with noise cancellation and 30-hour battery life.', 'headphones.jpg'),
('Smart Watch', 2499.00, 'Feature-packed smartwatch with health tracking, GPS, and 7-day battery.', 'smartwatch.jpg'),
('Laptop Stand', 799.50, 'Ergonomic aluminum laptop stand, adjustable height, compatible with all laptops.', 'laptopstand.jpg'),
('USB-C Hub', 549.00, '7-in-1 USB-C hub with HDMI, USB 3.0, SD card reader and PD charging.', 'usbhub.jpg'),
('Mechanical Keyboard', 1899.00, 'Compact TKL mechanical keyboard with RGB backlighting and tactile switches.', 'keyboard.jpg'),
('Webcam HD', 999.00, '1080p Full HD webcam with built-in microphone, perfect for video calls.', 'webcam.jpg');
