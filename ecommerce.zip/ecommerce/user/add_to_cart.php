<?php
// ============================================================
// user/add_to_cart.php
// Handles adding a product to the cart (session-based)
// ============================================================

session_start();

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get and sanitize product details from form
    $id    = (int)$_POST['product_id'];
    $name  = htmlspecialchars($_POST['product_name']);
    $price = (float)$_POST['product_price'];
    $image = htmlspecialchars($_POST['product_image']);

    // Validate required fields
    if ($id <= 0 || empty($name) || $price <= 0) {
        $_SESSION['msg_error'] = "Invalid product data.";
        header("Location: ../index.php");
        exit;
    }

    // Initialize cart if it doesn't exist yet
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if product already exists in cart - if yes, increase quantity
    if (isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id]['quantity']++;
    } else {
        // Add new item to cart
        $_SESSION['cart'][$id] = [
            'id'       => $id,
            'name'     => $name,
            'price'    => $price,
            'image'    => $image,
            'quantity' => 1
        ];
    }

    $_SESSION['msg'] = "\"$name\" added to cart!";
}

// Redirect back to homepage
header("Location: ../index.php");
exit;
?>
