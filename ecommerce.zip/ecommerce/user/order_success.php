<?php
// ============================================================
// user/order_success.php
// Shown after a successful checkout
// ============================================================

session_start();
require_once '../config/db.php';

// Get order ID from URL or session
$order_id = (int)($_GET['id'] ?? $_SESSION['order_id'] ?? 0);

if ($order_id <= 0) {
    header("Location: ../index.php");
    exit;
}

// Fetch order details from database
$result = mysqli_query($conn, "SELECT * FROM orders WHERE id = $order_id");
$order  = mysqli_fetch_assoc($result);

if (!$order) {
    header("Location: ../index.php");
    exit;
}

// Fetch order items
$items_result = mysqli_query($conn,
    "SELECT * FROM order_items WHERE order_id = $order_id"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Placed! - ShopZone</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">Shop<span>Zone</span></a>
        <ul class="navbar-nav">
            <li><a href="../index.php">🏠 Home</a></li>
        </ul>
    </div>
</nav>

<div class="container wrapper">
    <!-- Success Message -->
    <div class="order-success">
        <span class="checkmark">✅</span>
        <h2>Order Placed Successfully!</h2>
        <p>Thank you, <strong><?= htmlspecialchars($order['customer_name']) ?></strong>!<br>
           Your order <strong>#<?= $order_id ?></strong> has been placed.</p>

        <!-- Order Details Card -->
        <div class="card" style="max-width:500px; margin:28px auto; padding:24px; text-align:left;">
            <h3 style="margin-bottom:16px; font-size:1rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px;">Order Details</h3>

            <?php while ($item = mysqli_fetch_assoc($items_result)): ?>
                <div class="summary-row" style="margin-bottom:10px;">
                    <span>
                        <?= htmlspecialchars($item['product_name']) ?>
                        <span style="color:var(--text-muted);">× <?= $item['quantity'] ?></span>
                    </span>
                    <span>₹<?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                </div>
            <?php endwhile; ?>

            <hr class="divider">
            <div class="summary-row total">
                <span>Total Paid</span>
                <span>₹<?= number_format($order['total_amount'], 2) ?></span>
            </div>

            <div style="margin-top:16px; font-size:.85rem; color:var(--text-muted); line-height:1.8;">
                <div>📧 Confirmation sent to: <?= htmlspecialchars($order['customer_email']) ?></div>
                <div>📅 Order Date: <?= date('d M Y, h:i A', strtotime($order['order_date'])) ?></div>
                <div>🏠 Delivering to: <?= htmlspecialchars($order['customer_address']) ?></div>
            </div>
        </div>

        <a href="../index.php" class="btn btn-primary">Continue Shopping →</a>
    </div>
</div>

<footer class="footer">
    <p>© 2024 ShopZone &mdash; Built by mitrajsinh Gohil</p>
</footer>

</body>
</html>
<?php
mysqli_close($conn);
unset($_SESSION['order_id']); // Clean up session
?>
