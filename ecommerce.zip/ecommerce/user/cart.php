<?php
// ============================================================
// user/cart.php
// Displays the shopping cart with items, quantities, totals
// ============================================================

session_start();

// Handle remove item action
if (isset($_GET['remove'])) {
    $remove_id = (int)$_GET['remove'];
    if (isset($_SESSION['cart'][$remove_id])) {
        $name = $_SESSION['cart'][$remove_id]['name'];
        unset($_SESSION['cart'][$remove_id]);
        $_SESSION['msg'] = "\"$name\" removed from cart.";
    }
    header("Location: cart.php");
    exit;
}

// Handle update quantity action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    foreach ($_POST['qty'] as $prod_id => $qty) {
        $prod_id = (int)$prod_id;
        $qty     = (int)$qty;
        if ($qty <= 0) {
            // Remove item if quantity is 0 or less
            unset($_SESSION['cart'][$prod_id]);
        } elseif (isset($_SESSION['cart'][$prod_id])) {
            $_SESSION['cart'][$prod_id]['quantity'] = $qty;
        }
    }
    $_SESSION['msg'] = "Cart updated successfully.";
    header("Location: cart.php");
    exit;
}

// Handle clear cart
if (isset($_GET['clear'])) {
    unset($_SESSION['cart']);
    $_SESSION['msg'] = "Cart cleared.";
    header("Location: cart.php");
    exit;
}

// Calculate totals
$cart       = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$subtotal   = 0;
$item_count = 0;
foreach ($cart as $item) {
    $subtotal   += $item['price'] * $item['quantity'];
    $item_count += $item['quantity'];
}
$tax   = $subtotal * 0.18;  // 18% GST
$total = $subtotal + $tax;

$cart_count = count($cart); // distinct products
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart - ShopZone</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<!-- ========== NAVBAR ========== -->
<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">Shop<span>Zone</span></a>
        <ul class="navbar-nav">
            <li><a href="../index.php">🏠 Home</a></li>
            <li>
                <a href="cart.php" class="active">
                    🛒 Cart
                    <?php if ($cart_count > 0): ?>
                        <span class="cart-badge"><?= $cart_count ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <?php if (isset($_SESSION['admin_logged_in'])): ?>
                <li><a href="../admin/dashboard.php">⚙️ Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<div class="container wrapper">
    <!-- Breadcrumb -->
    <div class="breadcrumb">
        <a href="../index.php">Home</a>
        <span class="sep">/</span>
        <span>Shopping Cart</span>
    </div>

    <div class="page-header">
        <h2>🛒 Shopping Cart</h2>
        <?php if (!empty($cart)): ?>
            <a href="cart.php?clear=1"
               onclick="return confirm('Clear entire cart?')"
               class="btn btn-secondary btn-sm">
               🗑 Clear Cart
            </a>
        <?php endif; ?>
    </div>

    <?php if (isset($_SESSION['msg'])): ?>
        <div class="alert alert-success">✅ <?= htmlspecialchars($_SESSION['msg']) ?></div>
        <?php unset($_SESSION['msg']); ?>
    <?php endif; ?>

    <?php if (!empty($cart)): ?>
        <div class="checkout-grid">

            <!-- ===== Cart Items Table ===== -->
            <div>
                <form action="cart.php" method="POST">
                    <div class="card">
                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th>Subtotal</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cart as $item): ?>
                                    <tr>
                                        <!-- Product image + name -->
                                        <td>
                                            <div style="display:flex; align-items:center; gap:12px;">
                                                <?php
                                                $img = '../assets/images/' . $item['image'];
                                                if (file_exists($img) && $item['image'] !== 'default.jpg'):
                                                ?>
                                                    <img src="<?= $img ?>" alt="" class="cart-img">
                                                <?php else: ?>
                                                    <div class="cart-img" style="display:flex;align-items:center;justify-content:center;background:var(--surface2);border-radius:8px;font-size:1.4rem;">🖼️</div>
                                                <?php endif; ?>
                                                <span style="font-weight:500;"><?= htmlspecialchars($item['name']) ?></span>
                                            </div>
                                        </td>
                                        <td>₹<?= number_format($item['price'], 2) ?></td>
                                        <!-- Editable quantity input -->
                                        <td>
                                            <input type="number"
                                                   name="qty[<?= $item['id'] ?>]"
                                                   value="<?= $item['quantity'] ?>"
                                                   min="0" max="99"
                                                   class="qty-input">
                                        </td>
                                        <td style="color:var(--accent);font-weight:700;">
                                            ₹<?= number_format($item['price'] * $item['quantity'], 2) ?>
                                        </td>
                                        <td>
                                            <a href="cart.php?remove=<?= $item['id'] ?>"
                                               class="btn btn-danger btn-sm"
                                               onclick="return confirm('Remove this item?')">
                                               Remove
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Update Cart Button -->
                    <div style="margin-top:14px; display:flex; gap:12px;">
                        <button type="submit" name="update_cart" class="btn btn-secondary">
                            🔄 Update Cart
                        </button>
                        <a href="../index.php" class="btn btn-secondary">← Continue Shopping</a>
                    </div>
                </form>
            </div>

            <!-- ===== Order Summary Box ===== -->
            <div class="cart-summary">
                <h3>Order Summary</h3>
                <div class="summary-row">
                    <span>Items (<?= $item_count ?>)</span>
                    <span>₹<?= number_format($subtotal, 2) ?></span>
                </div>
                <div class="summary-row">
                    <span>GST (18%)</span>
                    <span>₹<?= number_format($tax, 2) ?></span>
                </div>
                <div class="summary-row">
                    <span>Shipping</span>
                    <span style="color:var(--success);">FREE</span>
                </div>
                <div class="summary-row total">
                    <span>Total</span>
                    <span>₹<?= number_format($total, 2) ?></span>
                </div>
                <div style="margin-top:20px;">
                    <a href="checkout.php" class="btn btn-primary btn-block">
                        Proceed to Checkout →
                    </a>
                </div>
            </div>

        </div>

    <?php else: ?>
        <!-- Empty cart state -->
        <div class="empty-state">
            <span class="empty-icon">🛒</span>
            <h3>Your cart is empty</h3>
            <p>Looks like you haven't added anything yet.</p>
            <a href="../index.php" class="btn btn-primary" style="margin-top:16px;">
                Start Shopping
            </a>
        </div>
    <?php endif; ?>
</div>

<footer class="footer">
    <p>© 2024 ShopZone &mdash; Built by Aaditya Sevani, Rudra Sedani, Maandeepsinh Gohil</p>
</footer>

</body>
</html>
