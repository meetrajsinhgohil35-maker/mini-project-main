<?php
// ============================================================
// user/checkout.php
// Checkout page - collects user details and places an order
// ============================================================

session_start();
require_once '../config/db.php';

// Redirect if cart is empty
if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit;
}

$errors  = [];
$success = false;

// ---------- Handle form submission ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get and validate form fields
    $name    = trim($_POST['customer_name']   ?? '');
    $email   = trim($_POST['customer_email']  ?? '');
    $address = trim($_POST['customer_address'] ?? '');
    $phone   = trim($_POST['customer_phone']  ?? '');

    if (empty($name))    $errors[] = "Full name is required.";
    if (empty($email))   $errors[] = "Email address is required.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($email))
                         $errors[] = "Please enter a valid email address.";
    if (empty($address)) $errors[] = "Delivery address is required.";
    if (empty($phone))   $errors[] = "Phone number is required.";
    if (!preg_match('/^[0-9]{10}$/', $phone) && !empty($phone))
                         $errors[] = "Phone must be a valid 10-digit number.";

    // If no errors, process order
    if (empty($errors)) {

        // Calculate total (with 18% GST)
        $subtotal = 0;
        foreach ($_SESSION['cart'] as $item) {
            $subtotal += $item['price'] * $item['quantity'];
        }
        $total = $subtotal * 1.18;

        // Escape values to prevent SQL injection
        $s_name    = mysqli_real_escape_string($conn, $name);
        $s_email   = mysqli_real_escape_string($conn, $email);
        $s_address = mysqli_real_escape_string($conn, $address);

        // Insert order into orders table
        $order_sql = "INSERT INTO orders (customer_name, customer_email, customer_address, total_amount)
                      VALUES ('$s_name', '$s_email', '$s_address', '$total')";

        if (mysqli_query($conn, $order_sql)) {
            $order_id = mysqli_insert_id($conn); // Get the new order ID

            // Insert each cart item into order_items
            foreach ($_SESSION['cart'] as $item) {
                $p_name  = mysqli_real_escape_string($conn, $item['name']);
                $p_price = (float)$item['price'];
                $p_qty   = (int)$item['quantity'];
                $p_id    = (int)$item['id'];

                mysqli_query($conn,
                    "INSERT INTO order_items (order_id, product_id, product_name, price, quantity)
                     VALUES ('$order_id', '$p_id', '$p_name', '$p_price', '$p_qty')"
                );
            }

            // Clear the cart after successful order
            unset($_SESSION['cart']);
            $_SESSION['order_id'] = $order_id;

            // Redirect to success page
            header("Location: order_success.php?id=$order_id");
            exit;

        } else {
            $errors[] = "Order could not be placed. Please try again.";
        }
    }
}

// Calculate totals for display
$cart     = $_SESSION['cart'];
$subtotal = 0;
$qty_total= 0;
foreach ($cart as $item) {
    $subtotal  += $item['price'] * $item['quantity'];
    $qty_total += $item['quantity'];
}
$tax   = $subtotal * 0.18;
$total = $subtotal + $tax;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - ShopZone</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<!-- ========== NAVBAR ========== -->
<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">Shop<span>Zone</span></a>
        <ul class="navbar-nav">
            <li><a href="../index.php">🏠 Home</a></li>
            <li><a href="cart.php">🛒 Cart <span class="cart-badge"><?= count($cart) ?></span></a></li>
        </ul>
    </div>
</nav>

<div class="container wrapper">
    <div class="breadcrumb">
        <a href="../index.php">Home</a>
        <span class="sep">/</span>
        <a href="cart.php">Cart</a>
        <span class="sep">/</span>
        <span>Checkout</span>
    </div>

    <div class="page-header">
        <h2>Checkout</h2>
    </div>

    <!-- Display validation errors -->
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            ❌ <?= implode('<br>❌ ', array_map('htmlspecialchars', $errors)) ?>
        </div>
    <?php endif; ?>

    <div class="checkout-grid">

        <!-- ===== Checkout Form ===== -->
        <div class="card" style="padding:28px;">
            <h3 style="margin-bottom:22px;">📦 Delivery Details</h3>
            <form action="checkout.php" method="POST">

                <div class="form-group">
                    <label class="form-label">Full Name *</label>
                    <input type="text" name="customer_name" class="form-control"
                           placeholder="Enter your full name"
                           value="<?= htmlspecialchars($_POST['customer_name'] ?? '') ?>"
                           required>
                </div>

                <div class="form-group">
                    <label class="form-label">Email Address *</label>
                    <input type="email" name="customer_email" class="form-control"
                           placeholder="example@email.com"
                           value="<?= htmlspecialchars($_POST['customer_email'] ?? '') ?>"
                           required>
                </div>

                <div class="form-group">
                    <label class="form-label">Phone Number *</label>
                    <input type="tel" name="customer_phone" class="form-control"
                           placeholder="10-digit mobile number"
                           value="<?= htmlspecialchars($_POST['customer_phone'] ?? '') ?>"
                           required maxlength="10">
                </div>

                <div class="form-group">
                    <label class="form-label">Delivery Address *</label>
                    <textarea name="customer_address" class="form-control"
                              placeholder="House no., Street, City, State, PIN"
                              required><?= htmlspecialchars($_POST['customer_address'] ?? '') ?></textarea>
                </div>

                <hr class="divider">

                <h3 style="margin-bottom:16px;">💳 Payment (Simulation)</h3>
                <div class="alert alert-warning">
                    ⚠️ This is a demo checkout. No real payment is processed.
                </div>

                <div class="form-group">
                    <label class="form-label">Payment Method</label>
                    <select name="payment_method" class="form-control">
                        <option value="cod">Cash on Delivery (COD)</option>
                        <option value="upi">UPI (Simulated)</option>
                        <option value="card">Credit/Debit Card (Simulated)</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-success btn-block" style="margin-top:8px;">
                    ✅ Place Order — ₹<?= number_format($total, 2) ?>
                </button>
            </form>
        </div>

        <!-- ===== Order Summary ===== -->
        <div>
            <div class="cart-summary">
                <h3>Order Review</h3>
                <?php foreach ($cart as $item): ?>
                    <div class="summary-row" style="flex-direction:column; align-items:flex-start; gap:2px; margin-bottom:14px;">
                        <span style="color:var(--text); font-weight:500;">
                            <?= htmlspecialchars($item['name']) ?>
                            <span style="color:var(--text-muted); font-weight:400;">× <?= $item['quantity'] ?></span>
                        </span>
                        <span>₹<?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                    </div>
                <?php endforeach; ?>

                <hr class="divider" style="margin:12px 0;">
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span>₹<?= number_format($subtotal, 2) ?></span>
                </div>
                <div class="summary-row">
                    <span>GST (18%)</span>
                    <span>₹<?= number_format($tax, 2) ?></span>
                </div>
                <div class="summary-row">
                    <span>Shipping</span>
                    <span style="color:var(--success);">FREE</span>
                </div>
                <div class="summary-row total">
                    <span>Total</span>
                    <span>₹<?= number_format($total, 2) ?></span>
                </div>
            </div>
        </div>

    </div>
</div>

<footer class="footer">
    <p>© 2024 ShopZone &mdash; Built by mitrajsinh gohil</p>
</footer>

</body>
</html>
<?php mysqli_close($conn); ?>
