<?php
// ============================================================
// config/db.php
// Database Connection Configuration
// ============================================================

// Database credentials - change these as per your local setup
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // Default XAMPP username
define('DB_PASS', '');           // Default XAMPP password (empty)
define('DB_NAME', 'ecommerce_db');

// Create a MySQLi connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check if connection was successful
if (!$conn) {
    die("
    <div style='font-family:sans-serif;padding:30px;background:#fee;border:1px solid red;margin:20px;border-radius:8px;'>
        <h2>❌ Database Connection Failed</h2>
        <p>" . mysqli_connect_error() . "</p>
        <p>Please check your database credentials in <strong>config/db.php</strong></p>
        <p>Make sure XAMPP MySQL service is running.</p>
    </div>");
}

// Set character set to utf8 for proper encoding
mysqli_set_charset($conn, "utf8");
?>
