<?php
// ============================================================
// admin/add_product.php
// Form to add a new product (CREATE operation)
// ============================================================

session_start();
require_once '../config/db.php';
require_once 'auth_check.php';

$errors  = [];
$success = false;

// ---------- Handle Form Submission ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get form data and sanitize
    $name        = trim($_POST['name']        ?? '');
    $price       = trim($_POST['price']       ?? '');
    $description = trim($_POST['description'] ?? '');

    // ---- Validation ----
    if (empty($name))
        $errors[] = "Product name is required.";
    if (strlen($name) > 100)
        $errors[] = "Product name must be under 100 characters.";
    if (empty($price))
        $errors[] = "Price is required.";
    if (!is_numeric($price) || $price <= 0)
        $errors[] = "Price must be a valid positive number.";
    if (empty($description))
        $errors[] = "Description is required.";

    // ---- Image Upload ----
    $image_name = 'default.jpg'; // Default if no image uploaded

    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $file      = $_FILES['image'];
        $file_ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed   = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (!in_array($file_ext, $allowed)) {
            $errors[] = "Only JPG, PNG, GIF, WEBP images are allowed.";
        } elseif ($file['size'] > 2 * 1024 * 1024) { // 2MB max
            $errors[] = "Image size must be less than 2MB.";
        } else {
            // Generate unique filename to avoid conflicts
            $image_name = uniqid('prod_') . '.' . $file_ext;
            $upload_dir = '../assets/images/';

            // Create upload directory if it doesn't exist
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            if (!move_uploaded_file($file['tmp_name'], $upload_dir . $image_name)) {
                $errors[] = "Failed to upload image. Check folder permissions.";
                $image_name = 'default.jpg';
            }
        }
    }

    // ---- Insert into Database if no errors ----
    if (empty($errors)) {
        $s_name  = mysqli_real_escape_string($conn, $name);
        $s_desc  = mysqli_real_escape_string($conn, $description);
        $s_price = (float)$price;
        $s_img   = mysqli_real_escape_string($conn, $image_name);

        $sql = "INSERT INTO products (name, price, description, image)
                VALUES ('$s_name', '$s_price', '$s_desc', '$s_img')";

        if (mysqli_query($conn, $sql)) {
            $_SESSION['msg']      = "Product \"$name\" added successfully!";
            $_SESSION['msg_type'] = 'success';
            header("Location: products.php");
            exit;
        } else {
            $errors[] = "Database error: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a href="dashboard.php" class="navbar-brand">Shop<span>Zone</span> <span style="font-size:.75rem;color:var(--text-muted);font-weight:400;font-family:'DM Sans'">Admin</span></a>
        <ul class="navbar-nav">
            <li><a href="../index.php">🏠 View Store</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-title">Navigation</div>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="products.php">📦 Products</a>
        <a href="add_product.php" class="active">➕ Add Product</a>
        <a href="orders.php">🧾 Orders</a>
        <div class="sidebar-title" style="margin-top:24px;">Account</div>
        <a href="../index.php">🏠 View Store</a>
        <a href="logout.php">🔐 Logout</a>
    </aside>

    <main class="admin-content">
        <div class="breadcrumb">
            <a href="dashboard.php">Dashboard</a>
            <span class="sep">/</span>
            <a href="products.php">Products</a>
            <span class="sep">/</span>
            <span>Add New</span>
        </div>

        <div class="page-header">
            <h2>➕ Add New Product</h2>
            <a href="products.php" class="btn btn-secondary btn-sm">← Back to Products</a>
        </div>

        <!-- Display validation errors -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $e): ?>
                    <div>❌ <?= htmlspecialchars($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Add Product Form -->
        <div class="card" style="max-width:640px; padding:32px;">
            <!-- enctype="multipart/form-data" is required for file uploads -->
            <form action="add_product.php" method="POST" enctype="multipart/form-data">

                <div class="form-group">
                    <label class="form-label">Product Name *</label>
                    <input type="text"
                           name="name"
                           class="form-control"
                           placeholder="e.g., Wireless Headphones"
                           value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                           maxlength="100"
                           required>
                </div>

                <div class="form-group">
                    <label class="form-label">Price (₹) *</label>
                    <input type="number"
                           name="price"
                           class="form-control"
                           placeholder="e.g., 1299.99"
                           value="<?= htmlspecialchars($_POST['price'] ?? '') ?>"
                           step="0.01"
                           min="0.01"
                           required>
                </div>

                <div class="form-group">
                    <label class="form-label">Description *</label>
                    <textarea name="description"
                              class="form-control"
                              placeholder="Describe the product features, specifications, etc."
                              required><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Product Image</label>
                    <input type="file"
                           name="image"
                           class="form-control"
                           accept="image/*"
                           onchange="previewImage(this)">
                    <p style="font-size:.78rem; color:var(--text-muted); margin-top:6px;">
                        Accepted: JPG, PNG, GIF, WEBP. Max size: 2MB. Leave empty to use placeholder.
                    </p>
                    <!-- Image Preview -->
                    <img id="preview" src="" alt="" style="display:none; margin-top:12px; max-width:200px; border-radius:8px; border:1px solid var(--border);">
                </div>

                <hr class="divider">

                <div style="display:flex; gap:12px;">
                    <button type="submit" class="btn btn-primary">➕ Add Product</button>
                    <a href="products.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </main>
</div>

<script>
// Preview image before upload
function previewImage(input) {
    const preview = document.getElementById('preview');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.src     = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

</body>
</html>
<?php mysqli_close($conn); ?>
