<?php
// ============================================================
// admin/orders.php
// View all placed orders with item details
// ============================================================

session_start();
require_once '../config/db.php';
require_once 'auth_check.php';

// Fetch all orders (newest first)
$orders = mysqli_query($conn, "SELECT * FROM orders ORDER BY order_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a href="dashboard.php" class="navbar-brand">Shop<span>Zone</span> <span style="font-size:.75rem;color:var(--text-muted);font-weight:400;font-family:'DM Sans'">Admin</span></a>
        <ul class="navbar-nav">
            <li><a href="../index.php">🏠 View Store</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-title">Navigation</div>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="products.php">📦 Products</a>
        <a href="add_product.php">➕ Add Product</a>
        <a href="orders.php" class="active">🧾 Orders</a>
        <div class="sidebar-title" style="margin-top:24px;">Account</div>
        <a href="../index.php">🏠 View Store</a>
        <a href="logout.php">🔐 Logout</a>
    </aside>

    <main class="admin-content">
        <div class="page-header">
            <h2>🧾 All Orders</h2>
            <span style="color:var(--text-muted); font-size:.85rem;">
                <?= mysqli_num_rows($orders) ?> total orders
            </span>
        </div>

        <?php if (mysqli_num_rows($orders) > 0): ?>
            <?php while ($order = mysqli_fetch_assoc($orders)): ?>

                <!-- Each order as an expandable card -->
                <div class="card" style="margin-bottom:16px; overflow:hidden;">

                    <!-- Order Header -->
                    <div style="display:flex; align-items:center; justify-content:space-between; padding:16px 20px; background:var(--surface2); flex-wrap:wrap; gap:10px; cursor:pointer;"
                         onclick="toggleOrder(<?= $order['id'] ?>)">
                        <div style="display:flex; gap:20px; align-items:center; flex-wrap:wrap;">
                            <span style="font-family:'Syne',sans-serif; font-weight:700; color:var(--accent);">
                                #<?= $order['id'] ?>
                            </span>
                            <span style="font-weight:500;"><?= htmlspecialchars($order['customer_name']) ?></span>
                            <span style="color:var(--text-muted); font-size:.85rem;">
                                <?= htmlspecialchars($order['customer_email']) ?>
                            </span>
                        </div>
                        <div style="display:flex; gap:16px; align-items:center;">
                            <span style="color:var(--success); font-weight:700; font-family:'Syne',sans-serif;">
                                ₹<?= number_format($order['total_amount'], 2) ?>
                            </span>
                            <span style="color:var(--text-muted); font-size:.82rem;">
                                <?= date('d M Y, h:i A', strtotime($order['order_date'])) ?>
                            </span>
                            <span style="font-size:.8rem; color:var(--text-muted);">▼</span>
                        </div>
                    </div>

                    <!-- Order Items (Hidden by default, shown on click) -->
                    <div id="order-<?= $order['id'] ?>" style="display:none; padding:16px 20px;">
                        <div style="margin-bottom:10px; font-size:.82rem; color:var(--text-muted);">
                            📍 <?= htmlspecialchars($order['customer_address']) ?>
                        </div>

                        <?php
                        // Fetch items for this specific order
                        $items = mysqli_query($conn,
                            "SELECT * FROM order_items WHERE order_id={$order['id']}"
                        );
                        ?>
                        <table style="width:100%;">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Qty</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($item = mysqli_fetch_assoc($items)): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($item['product_name']) ?></td>
                                        <td>₹<?= number_format($item['price'], 2) ?></td>
                                        <td><?= $item['quantity'] ?></td>
                                        <td style="color:var(--accent); font-weight:600;">
                                            ₹<?= number_format($item['price'] * $item['quantity'], 2) ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php endwhile; ?>

        <?php else: ?>
            <div class="empty-state">
                <span class="empty-icon">🧾</span>
                <h3>No Orders Yet</h3>
                <p>Orders will appear here once customers place them.</p>
            </div>
        <?php endif; ?>
    </main>
</div>

<script>
// Toggle show/hide order items on click
function toggleOrder(id) {
    const el = document.getElementById('order-' + id);
    el.style.display = (el.style.display === 'none') ? 'block' : 'none';
}
</script>

</body>
</html>
<?php mysqli_close($conn); ?>
