<?php
// ============================================================
// admin/auth_check.php
// Authentication Guard - Include this at top of every admin page
// This ensures only logged-in admins can access admin pages
// ============================================================

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Store intended page to redirect after login (optional enhancement)
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php");
    exit;
}
?>
