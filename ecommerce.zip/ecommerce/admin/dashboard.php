<?php
// ============================================================
// admin/dashboard.php
// Admin Dashboard - Overview statistics
// ============================================================

session_start();
require_once '../config/db.php';
require_once 'auth_check.php'; // Protect this page

// Fetch statistics for dashboard cards
$total_products = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM products"))[0];
$total_orders   = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM orders"))[0];
$total_revenue  = mysqli_fetch_row(mysqli_query($conn, "SELECT COALESCE(SUM(total_amount), 0) FROM orders"))[0];
$total_users    = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM users"))[0];

// Fetch 5 most recent orders
$recent_orders = mysqli_query($conn,
    "SELECT * FROM orders ORDER BY order_date DESC LIMIT 5"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ShopZone</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<!-- ========== NAVBAR ========== -->
<nav class="navbar">
    <div class="container">
        <a href="dashboard.php" class="navbar-brand">Shop<span>Zone</span> <span style="font-size:.75rem; color:var(--text-muted); font-weight:400; font-family:'DM Sans'">Admin</span></a>
        <ul class="navbar-nav">
            <li><a href="../index.php">🏠 View Store</a></li>
            <li style="color:var(--text-muted); font-size:.85rem; padding:0 8px;">
                👤 <?= htmlspecialchars($_SESSION['admin_name']) ?>
            </li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<!-- ========== ADMIN LAYOUT ========== -->
<div class="admin-layout">

    <!-- ===== Sidebar ===== -->
    <aside class="admin-sidebar">
        <div class="sidebar-title">Navigation</div>
        <a href="dashboard.php" class="active">📊 Dashboard</a>
        <a href="products.php">📦 Products</a>
        <a href="add_product.php">➕ Add Product</a>
        <a href="orders.php">🧾 Orders</a>
        <div class="sidebar-title" style="margin-top:24px;">Account</div>
        <a href="../index.php">🏠 View Store</a>
        <a href="logout.php">🔐 Logout</a>
    </aside>

    <!-- ===== Main Content ===== -->
    <main class="admin-content">
        <div class="page-header">
            <h2>📊 Dashboard</h2>
            <span style="color:var(--text-muted); font-size:.85rem;">
                Welcome back, <strong><?= htmlspecialchars($_SESSION['admin_name']) ?></strong>!
            </span>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $total_products ?></div>
                <div class="stat-label">📦 Total Products</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $total_orders ?></div>
                <div class="stat-label">🧾 Total Orders</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">₹<?= number_format($total_revenue, 0) ?></div>
                <div class="stat-label">💰 Revenue</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $total_users ?></div>
                <div class="stat-label">👤 Users</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div style="display:flex; gap:12px; margin-bottom:32px; flex-wrap:wrap;">
            <a href="add_product.php" class="btn btn-primary">➕ Add New Product</a>
            <a href="products.php"    class="btn btn-secondary">📦 Manage Products</a>
            <a href="orders.php"      class="btn btn-secondary">🧾 View Orders</a>
        </div>

        <!-- Recent Orders Table -->
        <div class="card">
            <div style="padding:20px 24px; border-bottom:1px solid var(--border);">
                <h3 style="font-size:1rem;">🕐 Recent Orders</h3>
            </div>
            <?php if (mysqli_num_rows($recent_orders) > 0): ?>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>#ID</th>
                                <th>Customer</th>
                                <th>Email</th>
                                <th>Amount</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = mysqli_fetch_assoc($recent_orders)): ?>
                                <tr>
                                    <td style="color:var(--accent); font-weight:700;">#<?= $order['id'] ?></td>
                                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                                    <td style="color:var(--text-muted);"><?= htmlspecialchars($order['customer_email']) ?></td>
                                    <td style="color:var(--success); font-weight:600;">
                                        ₹<?= number_format($order['total_amount'], 2) ?>
                                    </td>
                                    <td style="color:var(--text-muted); font-size:.85rem;">
                                        <?= date('d M Y', strtotime($order['order_date'])) ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <div style="padding:14px 24px;">
                    <a href="orders.php" class="btn btn-secondary btn-sm">View All Orders →</a>
                </div>
            <?php else: ?>
                <div style="padding:40px; text-align:center; color:var(--text-muted);">
                    No orders placed yet.
                </div>
            <?php endif; ?>
        </div>
    </main>

</div>

</body>
</html>
<?php mysqli_close($conn); ?>
