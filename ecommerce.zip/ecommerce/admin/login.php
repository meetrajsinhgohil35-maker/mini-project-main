<?php
// ============================================================
// admin/login.php
// Admin Login Page with session-based authentication
// ============================================================

session_start();
require_once '../config/db.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['admin_logged_in'])) {
    header("Location: dashboard.php");
    exit;
}

$error = '';

// ---------- Handle Login Form Submission ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Basic validation
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password.";
    } else {
        // Escape inputs to prevent SQL injection
        $username = mysqli_real_escape_string($conn, $username);
        $password = md5($password); // MD5 hash for password comparison

        // Query database for matching admin user
        $sql    = "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='admin'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);

            // Set session variables for admin
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id']        = $user['id'];
            $_SESSION['admin_name']      = $user['username'];

            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - ShopZone</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="login-page">
    <div class="login-box">
        <!-- Logo -->
        <div class="login-logo">⚙️ Admin Panel</div>
        <div class="login-sub">ShopZone Management System</div>

        <!-- Error Alert -->
        <?php if ($error): ?>
            <div class="alert alert-danger">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Login Form -->
        <form action="login.php" method="POST">

            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text"
                       name="username"
                       class="form-control"
                       placeholder="Enter admin username"
                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                       required
                       autocomplete="username">
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password"
                       name="password"
                       class="form-control"
                       placeholder="Enter password"
                       required
                       autocomplete="current-password">
            </div>

            <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px;">
                🔐 Login
            </button>
        </form>

        <!-- Default credentials hint for development -->
        <div style="text-align:center; margin-top:20px; padding:12px; background:var(--surface2); border-radius:8px; font-size:.8rem; color:var(--text-muted);">
            Default: <strong style="color:var(--text);">admin</strong> / <strong style="color:var(--text);">admin123</strong>
        </div>

        <div style="text-align:center; margin-top:16px;">
            <a href="../index.php" style="font-size:.85rem; color:var(--text-muted);">
                ← Back to Store
            </a>
        </div>
    </div>
</div>

</body>
</html>
<?php mysqli_close($conn); ?>
