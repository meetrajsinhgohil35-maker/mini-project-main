<?php
// ============================================================
// admin/products.php
// Displays all products with Edit and Delete options (READ + DELETE)
// ============================================================

session_start();
require_once '../config/db.php';
require_once 'auth_check.php';

// ---------- Handle Delete Action ----------
if (isset($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];

    // First, get the image filename to delete the file too
    $res  = mysqli_query($conn, "SELECT image FROM products WHERE id=$delete_id");
    $prod = mysqli_fetch_assoc($res);

    // Delete product from database
    if (mysqli_query($conn, "DELETE FROM products WHERE id=$delete_id")) {

        // Delete image file from server (if not the placeholder)
        if ($prod && $prod['image'] !== 'default.jpg') {
            $img_file = '../assets/images/' . $prod['image'];
            if (file_exists($img_file)) {
                unlink($img_file);
            }
        }
        $_SESSION['msg']      = "Product deleted successfully.";
        $_SESSION['msg_type'] = 'success';
    } else {
        $_SESSION['msg']      = "Error deleting product.";
        $_SESSION['msg_type'] = 'danger';
    }
    header("Location: products.php");
    exit;
}

// Fetch all products
$result = mysqli_query($conn, "SELECT * FROM products ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a href="dashboard.php" class="navbar-brand">Shop<span>Zone</span> <span style="font-size:.75rem;color:var(--text-muted);font-weight:400;font-family:'DM Sans'">Admin</span></a>
        <ul class="navbar-nav">
            <li><a href="../index.php">🏠 View Store</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-title">Navigation</div>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="products.php" class="active">📦 Products</a>
        <a href="add_product.php">➕ Add Product</a>
        <a href="orders.php">🧾 Orders</a>
        <div class="sidebar-title" style="margin-top:24px;">Account</div>
        <a href="../index.php">🏠 View Store</a>
        <a href="logout.php">🔐 Logout</a>
    </aside>

    <main class="admin-content">
        <div class="page-header">
            <h2>📦 Products</h2>
            <a href="add_product.php" class="btn btn-primary">➕ Add New Product</a>
        </div>

        <!-- Flash Messages -->
        <?php if (isset($_SESSION['msg'])): ?>
            <div class="alert alert-<?= $_SESSION['msg_type'] ?? 'success' ?>">
                <?= $_SESSION['msg_type'] === 'success' ? '✅' : '❌' ?>
                <?= htmlspecialchars($_SESSION['msg']) ?>
            </div>
            <?php unset($_SESSION['msg'], $_SESSION['msg_type']); ?>
        <?php endif; ?>

        <!-- Products Table -->
        <div class="card">
            <div class="table-wrap">
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Description</th>
                                <th>Added On</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($product = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td style="color:var(--text-muted);"><?= $product['id'] ?></td>

                                    <!-- Product Image Thumbnail -->
                                    <td>
                                        <?php
                                        $img = '../assets/images/' . $product['image'];
                                        if (file_exists($img) && $product['image'] !== 'default.jpg'):
                                        ?>
                                            <img src="<?= $img ?>" alt="" class="admin-prod-img">
                                        <?php else: ?>
                                            <div class="admin-prod-img" style="display:flex;align-items:center;justify-content:center;background:var(--surface2);border-radius:8px;font-size:1.3rem;">🖼️</div>
                                        <?php endif; ?>
                                    </td>

                                    <td style="font-weight:500;"><?= htmlspecialchars($product['name']) ?></td>
                                    <td style="color:var(--accent); font-weight:700;">
                                        ₹<?= number_format($product['price'], 2) ?>
                                    </td>
                                    <td style="color:var(--text-muted); font-size:.85rem; max-width:200px;">
                                        <?= htmlspecialchars(substr($product['description'], 0, 60)) ?>...
                                    </td>
                                    <td style="color:var(--text-muted); font-size:.82rem; white-space:nowrap;">
                                        <?= date('d M Y', strtotime($product['created_at'])) ?>
                                    </td>

                                    <!-- Action Buttons -->
                                    <td>
                                        <div style="display:flex; gap:8px;">
                                            <a href="edit_product.php?id=<?= $product['id'] ?>"
                                               class="btn btn-secondary btn-sm">✏️ Edit</a>
                                            <a href="products.php?delete=<?= $product['id'] ?>"
                                               class="btn btn-danger btn-sm"
                                               onclick="return confirm('Are you sure you want to delete this product? This cannot be undone.')">
                                               🗑 Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div style="padding:50px; text-align:center; color:var(--text-muted);">
                        <div style="font-size:3rem; margin-bottom:12px;">📦</div>
                        <h3 style="color:var(--text);">No Products Yet</h3>
                        <p style="margin:8px 0 20px;">Start by adding your first product.</p>
                        <a href="add_product.php" class="btn btn-primary">➕ Add Product</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

</body>
</html>
<?php mysqli_close($conn); ?>
