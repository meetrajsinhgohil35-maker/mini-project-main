<?php
// ============================================================
// admin/logout.php
// Destroys admin session and redirects to login page
// ============================================================

session_start();

// Remove only admin session variables (keep cart session if any)
unset($_SESSION['admin_logged_in']);
unset($_SESSION['admin_id']);
unset($_SESSION['admin_name']);

// Optionally destroy entire session
// session_destroy();

header("Location: login.php");
exit;
?>
