<?php
// ============================================================
// admin/edit_product.php
// Edit an existing product (UPDATE operation)
// ============================================================

session_start();
require_once '../config/db.php';
require_once 'auth_check.php';

// Get product ID from URL
$product_id = (int)($_GET['id'] ?? 0);

// Validate product ID
if ($product_id <= 0) {
    header("Location: products.php");
    exit;
}

// Fetch existing product data from database
$result  = mysqli_query($conn, "SELECT * FROM products WHERE id=$product_id");
$product = mysqli_fetch_assoc($result);

// If product not found, redirect
if (!$product) {
    $_SESSION['msg']      = "Product not found.";
    $_SESSION['msg_type'] = 'danger';
    header("Location: products.php");
    exit;
}

$errors = [];

// ---------- Handle Form Submission (Update) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name        = trim($_POST['name']        ?? '');
    $price       = trim($_POST['price']       ?? '');
    $description = trim($_POST['description'] ?? '');

    // ---- Validation ----
    if (empty($name))
        $errors[] = "Product name is required.";
    if (empty($price) || !is_numeric($price) || $price <= 0)
        $errors[] = "Price must be a valid positive number.";
    if (empty($description))
        $errors[] = "Description is required.";

    // ---- Handle Image (keep old one if no new image uploaded) ----
    $image_name = $product['image']; // Keep current image by default

    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $file      = $_FILES['image'];
        $file_ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed   = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (!in_array($file_ext, $allowed)) {
            $errors[] = "Only JPG, PNG, GIF, WEBP images are allowed.";
        } elseif ($file['size'] > 2 * 1024 * 1024) {
            $errors[] = "Image size must be less than 2MB.";
        } else {
            // Upload new image
            $new_image  = uniqid('prod_') . '.' . $file_ext;
            $upload_dir = '../assets/images/';

            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_image)) {
                // Delete old image file (if not default)
                if ($image_name !== 'default.jpg' && file_exists($upload_dir . $image_name)) {
                    unlink($upload_dir . $image_name);
                }
                $image_name = $new_image;
            } else {
                $errors[] = "Failed to upload new image.";
            }
        }
    }

    // ---- Update Database if no errors ----
    if (empty($errors)) {
        $s_name  = mysqli_real_escape_string($conn, $name);
        $s_desc  = mysqli_real_escape_string($conn, $description);
        $s_price = (float)$price;
        $s_img   = mysqli_real_escape_string($conn, $image_name);

        $sql = "UPDATE products
                SET name='$s_name', price='$s_price', description='$s_desc', image='$s_img'
                WHERE id=$product_id";

        if (mysqli_query($conn, $sql)) {
            $_SESSION['msg']      = "Product \"$name\" updated successfully!";
            $_SESSION['msg_type'] = 'success';
            header("Location: products.php");
            exit;
        } else {
            $errors[] = "Database error: " . mysqli_error($conn);
        }
    }

    // Update local $product array to repopulate form with submitted data on error
    $product['name']        = $name;
    $product['price']       = $price;
    $product['description'] = $description;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a href="dashboard.php" class="navbar-brand">Shop<span>Zone</span> <span style="font-size:.75rem;color:var(--text-muted);font-weight:400;font-family:'DM Sans'">Admin</span></a>
        <ul class="navbar-nav">
            <li><a href="../index.php">🏠 View Store</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-title">Navigation</div>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="products.php" class="active">📦 Products</a>
        <a href="add_product.php">➕ Add Product</a>
        <a href="orders.php">🧾 Orders</a>
        <div class="sidebar-title" style="margin-top:24px;">Account</div>
        <a href="../index.php">🏠 View Store</a>
        <a href="logout.php">🔐 Logout</a>
    </aside>

    <main class="admin-content">
        <div class="breadcrumb">
            <a href="dashboard.php">Dashboard</a>
            <span class="sep">/</span>
            <a href="products.php">Products</a>
            <span class="sep">/</span>
            <span>Edit Product</span>
        </div>

        <div class="page-header">
            <h2>✏️ Edit Product</h2>
            <a href="products.php" class="btn btn-secondary btn-sm">← Back to Products</a>
        </div>

        <!-- Display validation errors -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $e): ?>
                    <div>❌ <?= htmlspecialchars($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Edit Product Form -->
        <div class="card" style="max-width:640px; padding:32px;">
            <form action="edit_product.php?id=<?= $product_id ?>" method="POST" enctype="multipart/form-data">

                <div class="form-group">
                    <label class="form-label">Product Name *</label>
                    <input type="text"
                           name="name"
                           class="form-control"
                           value="<?= htmlspecialchars($product['name']) ?>"
                           maxlength="100"
                           required>
                </div>

                <div class="form-group">
                    <label class="form-label">Price (₹) *</label>
                    <input type="number"
                           name="price"
                           class="form-control"
                           value="<?= htmlspecialchars($product['price']) ?>"
                           step="0.01"
                           min="0.01"
                           required>
                </div>

                <div class="form-group">
                    <label class="form-label">Description *</label>
                    <textarea name="description"
                              class="form-control"
                              required><?= htmlspecialchars($product['description']) ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Current Image</label>
                    <?php
                    $cur_img = '../assets/images/' . $product['image'];
                    if (file_exists($cur_img) && $product['image'] !== 'default.jpg'):
                    ?>
                        <img src="<?= $cur_img ?>" alt="" style="max-width:150px; border-radius:8px; border:1px solid var(--border); display:block; margin-bottom:10px;">
                    <?php else: ?>
                        <div style="display:flex;align-items:center;justify-content:center;background:var(--surface2);border-radius:8px;font-size:2.5rem;width:100px;height:80px;margin-bottom:10px;">🖼️</div>
                    <?php endif; ?>

                    <label class="form-label">Upload New Image (optional)</label>
                    <input type="file"
                           name="image"
                           class="form-control"
                           accept="image/*"
                           onchange="previewImage(this)">
                    <p style="font-size:.78rem; color:var(--text-muted); margin-top:6px;">
                        Leave empty to keep current image.
                    </p>
                    <img id="preview" src="" alt="" style="display:none; margin-top:12px; max-width:200px; border-radius:8px; border:1px solid var(--border);">
                </div>

                <hr class="divider">

                <div style="display:flex; gap:12px;">
                    <button type="submit" class="btn btn-primary">💾 Update Product</button>
                    <a href="products.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </main>
</div>

<script>
function previewImage(input) {
    const preview = document.getElementById('preview');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.src           = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

</body>
</html>
<?php mysqli_close($conn); ?>
